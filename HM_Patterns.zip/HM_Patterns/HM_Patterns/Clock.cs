﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HM_Singeltone
{
    class Clock
    {
        private long Time = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        private Clock()
        {
            
        }

        private static Clock instance;

        public static Clock GetInctance()
        {
            if (instance == null)
            {
                instance = new Clock();
            }
            return instance;
        }

        public void GetTime()
        {
            Console.WriteLine($"time stemp is: {Time}");
        }
    }
}
