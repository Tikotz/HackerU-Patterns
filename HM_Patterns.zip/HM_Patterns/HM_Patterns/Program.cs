﻿using HM_Singeltone;


var Moshe = Clock.GetInctance();
Thread.Sleep(1000);
var Moshe1 = Clock.GetInctance();


Moshe.GetTime();

Thread.Sleep(1000);

Moshe1.GetTime();




